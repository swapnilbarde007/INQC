package com.example.Vaccination;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VaccinationApplicationTests {

	@Test
	void contextLoads() {
	}

}
