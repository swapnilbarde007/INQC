package com.example.EventRegistration;

public interface College {


    // This method returns the college name.
    String getCollegeName();

    // This method returns the CollegeEvent.
    CollegeEvent getEvent();
}
